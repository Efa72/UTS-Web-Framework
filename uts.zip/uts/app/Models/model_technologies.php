<?php

namespace App\Models;

use CodeIgniter\Model;

class model_technologies extends Model
{

    public function getdata()
    {
        $query = $this->db->query("SElECT * FROM technology ORDER BY teknologi ASC");
        return $query->getResult();
    }
}
