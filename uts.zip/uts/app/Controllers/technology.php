<?php

namespace App\Controllers;

use App\Models\model_technologies;

class technology extends BaseController
{
    protected $mtechnology;
    public function __construct()
    {

        $this->mtechnology = new model_technologies();
    }
    public function index()
    {
        $getdata = $this->mtechnology->getdata();
        $data = array(
            'dataTechnology' => $getdata,
        );

        return view('pages/technologies', $data);
    }
}
