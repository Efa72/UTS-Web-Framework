<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<?php

use App\Controllers\technology;
use CodeIgniter\Controller;
?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>Technologies</h1>
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-Black">AMD Technologies</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Technology</th>
                                    <th>Deskripsi</th>
                                    <th>Thumbnail</th>
                                    <th>Created At</th>
                                    <th>Updated At</th>
                                </tr>
                                <?php $no = 1;
                                foreach ($dataTechnology as $row) : ?>
                            </thead>
                            <tfoot>
                                <tr>
                                    <td> <?= $no++; ?></td>
                                    <td> <?= $row->teknologi; ?></td>
                                    <td> <?= $row->deskripsi; ?></td>
                                    <td> <?= $row->created_at; ?></td>
                                    <td> <?= $row->updated_at; ?></td>

                                </tr>
                            <?php endforeach
                                # code...
                            ?>
                            </tfoot>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>