<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>


<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">

<title>UTS Framework</title>

<!-- Custom fonts for this template-->
<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

<!-- Custom styles for this template-->
<link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->

        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->

                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-3">
                        <h1 class="font-weight-bold text-black">AMD</h1>
                    </div>


                    <!-- Basic Card Example -->
                    <div class="card shadow mb-2">
                        <div class="card bg-black text-white shadow">
                            <div class="card-header py-3">
                                <h2 class="m-0 font-weight-bold text-black">The World’s Fastest PC Gaming Processor</h2>
                            </div>
                            <div class="card-body">

                                Get an average of 15% more performance with AMD Ryzen™ 7 5800X3D, the only processor with AMD 3D V-Cache™ technology.1
                            </div>
                        </div>
                    </div>

                    <div class="row">

                        <div class="col-lg-6">
                            <!-- Collapsable Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card bg-dark text-white shadow">
                                    <!-- Card Header - Accordion -->
                                    <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
                                        <h6 class="m-0 font-weight-bold text-black">Meet the world’s highest-performing server processors for technical computing³ </h6>
                                    </a>
                                    <!-- Card Content - Collapse -->
                                    <div class="collapse show" id="collapseCardExample">
                                        <div class="card-body">
                                            AMD EPYC™ 7003 Series processors with AMD 3D V-Cache™
                                            technology accelerate simulations, boost engineering productivity,
                                            and speed the product development process.
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Basic Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card bg-secondary text-white shadow">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-black">AMD Instinct™ MI Series Accelerators</h6>
                                    </div>
                                    <div class="card-body">
                                        The era of exascale is here. Immense computational power coupled with the convergence of HPC and AI is enabling researchers to tackle grand challenges once thought beyond reach.
                                    </div>
                                </div>
                            </div>

                            <!-- Basic Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card bg-dark text-white shadow">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-black">Play It All with Ryzen™ and Radeon™</h6>
                                    </div>
                                    <div class="card-body">
                                        AMD Ryzen™ processors and Radeon™ graphics enable the ultimate gaming platform for any gamer.
                                    </div>
                                </div>
                            </div>

                            <!-- Dropdown Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card bg-secondary text-white shadow">
                                    <!-- Card Header - Dropdown -->
                                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                        <h6 class="m-0 font-weight-bold text-black">AMD Smart Access Memory</h6>
                                        <div class="dropdown no-arrow">
                                            <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                                                <div class="dropdown-header">Dropdown Header:</div>
                                                <a class="dropdown-item" href="#">Action</a>
                                                <a class="dropdown-item" href="#">Another action</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item" href="#">Something else here</a>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Card Body -->
                                    <div class="card-body">
                                        Get Up to 15% More Gaming Performance with AMD Smart Access Memory
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="col-lg-6">

                            <!-- Dropdown Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card bg-secondary text-white shadow">
                                    <!-- Card Header - Dropdown -->
                                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                        <h6 class="m-0 font-weight-bold text-black">Performance to Rule Your Game</h6>
                                        <div class="dropdown no-arrow">
                                            <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                                                <div class="dropdown-header">Dropdown Header:</div>
                                                <a class="dropdown-item" href="#">Action</a>
                                                <a class="dropdown-item" href="#">Another action</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item" href="#">Something else here</a>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Card Body -->
                                    <div class="card-body">
                                        Introducing the AMD Radeon™ RX 6000 Series graphics cards,
                                        featuring the breakthrough AMD RDNA™ 2 architecture,
                                        engineered to deliver ultra-high performance, ultra-high resolution,
                                        visually stunning gaming for all. We’re powering the next generation of gaming
                                    </div>
                                </div>
                            </div>

                            <!-- Collapsable Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card bg-dark text-white shadow">
                                    <!-- Card Header - Accordion -->
                                    <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
                                        <h6 class="m-0 font-weight-bold text-black">Bringing Exascale-Class Technologies to Mainstream HPC & AI</h6>
                                    </a>
                                    <!-- Card Content - Collapse -->
                                    <div class="collapse show" id="collapseCardExample">
                                        <div class="card-body">
                                            Introducing AMD Instinct™ MI210 Accelerator
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Basic Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card bg-secondary text-white shadow">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-black">Those Who Know Performance Know AMD Ryzen™</h6>
                                    </div>
                                    <div class="card-body">
                                        Explore infinite possibilities with the new AMD Ryzen™ 6000 Series Processor.
                                        Speed. Endurance. Infinite Possibilities. <br>
                                        Awaken your senses to refreshing speed, with the confidence to unplug and go further.
                                        New AMD Ryzen™ 6000 Series processors bring new experiences to life - delivering everything you need, and so much more.

                                    </div>
                                </div>
                            </div>

                            <!-- Collapsable Card Example -->
                            <div class="card shadow mb-4">
                                <div class="card bg-dark text-white shadow">
                                    <!-- Card Header - Accordion -->
                                    <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
                                        <h6 class="m-0 font-weight-bold text-black">AMD Radeon™ ProRender</h6>
                                    </a>
                                    <!-- Card Content - Collapse -->
                                    <div class="collapse show" id="collapseCardExample">
                                        <div class="card-body">
                                            <strong> Fast. Easy. Incredible.<br></strong>
                                            AMD Radeon™ ProRender is the AMD high-performance, physically-based rendering engine.
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>


                    <div class="row">
                        <a>Find Retailers</a>

                        <!-- Earnings (Monthly) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-danger shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
                                                North America</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <a href="https://www.amazon.com/stores/page/09DCAE89-ECF8-4F1C-8964-F62016A14699?ingress=0&visitId=63459362-6378-4974-941b-e5c765ed24cf">Amazon </a>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Earnings (Annual) Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                Western Europe</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <a href="https://www.materiel.net/carte-graphique/l426/+fv121-19923/">Materiel.net</a>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Tasks Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Greater China and Asia Pacific
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <a href="https://www.scorptec.com.au/product/graphics-cards/radeonrx6700xt?page=1">Scorptec Computers</a>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Pending Requests Card Example -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                Middle East and Africa</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                <a href="https://www.evetech.co.za/PC-Components/buy-amd-radeon-graphcis-cards-39.aspx">Evetech</a>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->

            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>
</div>
</div>
</div>
<?= $this->endSection(); ?>