<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>


<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">

<title>UTS Framework</title>

<!-- Custom fonts for this template-->
<link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

<!-- Custom styles for this template-->
<link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->

        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->

                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h1 mb-0 font-weight-bold text-gray-800">About AMD</h1>
                    </div>


                    <!-- Basic Card Example -->
                    <div class="card shadow mb-2">
                        <div class="card bg-black text-white shadow">
                            <div class="card-header py-3">
                                <h2 class="m-1 font-weight-bold text-white">AMD Acquires Xilinx</h2>
                            </div>
                            <div class="card-body">
                                Creating the Industry’s High Performance and Adaptive Computing Leader
                            </div>
                        </div>
                    </div>

                    <div class="row">



                        <!-- Basic Card Example -->
                        <div class="card shadow mb-4">
                            <div class="card bg-dark text-white shadow">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-white">Our History </h6>
                                </div>
                                <div class="card-body">
                                    Founded in 1969 as a Silicon Valley start-up, the AMD journey began with dozens of employees focused on leading-edge semiconductor products. From those modest beginnings, AMD has grown into a global company setting the standard for modern computing through major technological achievements and many important industry firsts along the way.
                                    Rooted in an innovation-driven culture, AMD employees collaborate every day to maximize the potential of modern computing, utilizing semiconductor innovation to transform how people live, work, learn and play.
                                    Today, AMD offers the industry’s broadest portfolio of leadership high-performance and adaptive processor technologies, combining CPUs, GPUs, FPGAs, Adaptive SoCs and deep software expertise to enable leadership computing platforms for cloud, edge and end devices.
                                </div>
                            </div>
                        </div>

                        <!-- Basic Card Example -->
                        <div class="card shadow mb-4">
                            <div class="card bg-dark text-white shadow">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-white">Our Vision</h6>
                                </div>
                                <div class="card-body">
                                    High performance and adaptive computing is transforming our lives.
                                </div>
                            </div>
                        </div>


                        <!-- Basic Card Example -->
                        <div class="card shadow mb-4">
                            <div class="card bg-dark text-white shadow">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-white">Our Mission</h6>
                                </div>
                                <div class="card-body">
                                    Build great products that accelerate next-generation computing experiences.​

                                </div>
                            </div>
                        </div>


                        <!-- Basic Card Example -->
                        <div class="card shadow mb-4">
                            <div class="card bg-primary text-white shadow">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-white">Corporate Responsibility at AMD</h6>
                                </div>
                                <div class="card-body">
                                    Embedding corporate responsibility across our value chain and the communities where we live and work
                                </div>
                            </div>
                        </div>

                    </div>
                </div>




            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Footer -->

        <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>
</div>
</div>
</div>
<?= $this->endSection(); ?>